@echo off
:: Automatically elevate to Administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -Command "Start-Process -FilePath '%0' -Verb RunAs"
    exit /b
)

:menu
cls
echo ==========================================
echo       VMware Service Manager
echo ==========================================
echo.
echo What would you like to do?
echo.
echo [1] Start VMware services
echo [2] Stop VMware services
echo [3] Exit
echo.
echo ==========================================
set /p choice="Enter your choice (1-3): "

if "%choice%"=="1" goto start_vmware
if "%choice%"=="2" goto stop_vmware
if "%choice%"=="3" goto exit_script
goto menu

:start_vmware
echo.
echo Restoring service startup types...
sc config "VMUSBArbService" start= demand >nul

echo Starting VMware services...
net start "VMAuthdService"
net start "VMwareHostd"
net start "VMnetDHCP"
net start "VMware NAT Service"
net start "VMUSBArbService"
echo.
echo All core VMware services have been requested to start.
pause
goto menu

:stop_vmware
echo.
echo Forcing VMware services to stop...

:: Forcefully stop the USB Arbitration service by disabling and stopping it
sc config "VMUSBArbService" start= disabled >nul
net stop "VMUSBArbService" /y >nul 2>&1

:: Stop the remaining services
net stop "VMAuthdService" /y
net stop "VMwareHostd" /y
net stop "VMnetDHCP" /y
net stop "VMware NAT Service" /y
echo.
echo All core VMware services have been stopped.
pause
goto menu

:exit_script
echo.
echo Exiting...
timeout /t 2 >nul
exit